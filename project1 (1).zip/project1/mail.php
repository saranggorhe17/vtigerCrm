 <?php
 
 session_start();
//  $name = $_POST['name'];
//  $email = $_POST['email'];
//  $subject = $_POST['phone'];
//  $message = $_POST['message'];
//   $to = "sanketbhakare400@gmail.com";
//   $subject = "Mail From Team04 website";
//   $txt = "Name = ".$name."\r\n Email = ".$email. "\r\n Message = ".$message.
//   "\r\n Mobile Number = ".$number;
//   $headers = "From: noreply@Team04.com"."\r\n"."CC:somebodyelse@example.com";

//   if($email!=NULL){
//     mail($to, $subject, $txt, $headers);
//   }
// header(Location:thanku.html);

 
//  or die("Error!");
 echo' 

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body>
   
    <header>
    <nav>
    <div class="logo">JOB<pp>PORTAL</pp></div>
      <input type="checkbox" id="click">
      <label for="click" class="menu-btn">
        <i class="fas fa-bars"></i>
      </label>
      <ul>
      <li><a  href="index.php">HOME</a></li>
      <li><a  href="interview.html">INTERVIEW PREP</a></li>
      <li><a  href="about.html">ABOUT US </a></li>
      <li><a  href="contact.html">CONTACT US</a></li>
      </ul>
    </nav>
  </header>

  <main class="background-image" >
  
    <div class="contact">
      <pi class="pll">Thank you for contacting us. We will get back to you as soon as possible!</pi>
    </div>
  </main>
  
  <footer>
    <p></p> Created By <a>Team04</a>
    |@2022 All rights reserved</p>
  </footer>
  </body>
</html>


';
?>